#pip install opencv-python

# 00  ----------------------
import cv2

# 01  ----------------------s
cap = cv2.VideoCapture('A01.mp4')
#cap = cv2.VideoCapture(0)


# 02  ----------------------
while (True):

    (ret, frame) = cap.read()
    if not ret:
        break
    small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)  
    hsv = cv2.cvtColor(small_frame, cv2.COLOR_BGR2HSV)
  
    cv2.imshow("HSV", hsv)
    cv2.imshow('video original',small_frame)

    if (cv2.waitKey(1) == 113): #q para salir
        break
# 03  ----------------------
cap.release()
cv2.destroyAllWindows()
