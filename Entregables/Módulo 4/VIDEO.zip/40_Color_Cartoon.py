#pip install opencv-python
#pip install numpy

# 00  ----------------------
import cv2
import numpy as np

# 01  ----------------------
##capture = cv2.VideoCapture(0)
capture = cv2.VideoCapture('A01.mp4')

def cartoonize (image):
  gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
  edges = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 9, 9)
  color = cv2.bilateralFilter(image, 9, 200, 200)
  cartoon = cv2.bitwise_and(color, color, mask = edges)
  return cartoon

# 02  ----------------------
while (True):


    (ret, frame) = capture.read()
    if not ret:
        break
      
    small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)    
    cartoonImage = cartoonize(small_frame)

    cv2.imshow("Cartoon", cartoonImage)
    cv2.imshow('video original', small_frame)

    if cv2.waitKey(1) == 113: #q para salir
        break
# 03  ----------------------
capture.release()
cv2.destroyAllWindows()
