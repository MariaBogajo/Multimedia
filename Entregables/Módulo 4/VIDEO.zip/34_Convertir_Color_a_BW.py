# 00  ----------------------
import cv2

# 01  ----------------------
cap = cv2.VideoCapture('A01.mp4')
#cap = cv2.VideoCapture(0)

# 02  ----------------------
while cap.isOpened():
    ret, frame = cap.read()

    if not ret:
        break

    small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
    gray_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2GRAY)
    ret, black_and_white_frame = cv2.threshold(gray_frame, 127, 255, cv2.THRESH_BINARY)

    cv2.imshow('video bw', black_and_white_frame)
    cv2.imshow('video original', small_frame)

    if cv2.waitKey(1) & 0xFF == ord('q'): # q para salir
        break

# 02  ----------------------
cap.release()
cv2.destroyAllWindows()
