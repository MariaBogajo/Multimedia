#pip install opencv-python
#pip install numpy

# 00  ----------------------
import cv2
import numpy as np

# 01  ----------------------
cap = cv2.VideoCapture('A01.mp4')
##cap = cv2.VideoCapture(0)

def pencil (image):
  sk_gray, skColor = cv2.pencilSketch(image, sigma_s = 60, sigma_r = 0.07, shade_factor = 0.1)

  return skColor

# 02  ----------------------
while (True):

    (ret, frame) = cap.read()
    if not ret:
        break
    small_frame = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
    
    pencilImage = pencil(small_frame)
    
    cv2.imshow("Lapiz", pencilImage)
    cv2.imshow('video original', small_frame)

    if cv2.waitKey(1) == 113: #q para salir
        break
# 03  ----------------------
cap.release()
cv2.destroyAllWindows()
